<?php

namespace MGS\StoreLocator\Block;

class Toplink extends \Magento\Framework\View\Element\Html\Link
{

}
