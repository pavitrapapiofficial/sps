var config = {
	"map": {
		"*": {
			"mgs/owlcarousel": "MGS_Mpanel/js/owl.carousel.min",
		}
	},
	"paths": {            
		"mgs/owlcarousel": "MGS_Mpanel/js/owl.carousel.min"
	},   
    "shim": {"MGS_Mpanel/js/owl.carousel.min": ["jquery"]}
};